<div align="center">
<a href="https://douyin.wtf/" alt="logo"><img src="./logo/logo.svg" width="120" alt="Douyin_TikTok_Download_API"/></a>
</div>
<h1 align="center">Douyin_TikTok_Download_API</h1>

<div align="center">

[English](./README.md) | [简体中文](./README.zh-CN.md)

🚀 A self-hosted data API for [Douyin](https://www.douyin.com) and [TikTok](https://www.tiktok.com). One `docker compose up`, an identity pool that maintains itself, and a REST API, MCP server and web console on top.

Open source, free, and it runs on your own machine — no signup, no quota, nobody else in the path. It fetches posts, authors, comments and search, downloads video and image albums **without a watermark** (it picks the clean stream the platform already publishes rather than stripping anything), and keeps what it collects in your own PostgreSQL.

[![GitHub license](https://img.shields.io/github/license/Evil0ctal/Douyin_TikTok_Download_API?style=flat-square)](LICENSE)
[![Release Version](https://img.shields.io/github/v/release/Evil0ctal/Douyin_TikTok_Download_API?style=flat-square)](https://github.com/Evil0ctal/Douyin_TikTok_Download_API/releases/latest)
[![GitHub Star](https://img.shields.io/github/stars/Evil0ctal/Douyin_TikTok_Download_API?style=flat-square)](https://github.com/Evil0ctal/Douyin_TikTok_Download_API/stargazers)
[![GitHub forks](https://img.shields.io/github/forks/Evil0ctal/Douyin_TikTok_Download_API?style=flat-square)](https://github.com/Evil0ctal/Douyin_TikTok_Download_API/forks)
[![GitHub issues](https://img.shields.io/github/issues/Evil0ctal/Douyin_TikTok_Download_API?style=flat-square)](https://github.com/Evil0ctal/Douyin_TikTok_Download_API/issues)
<br>
[![CI](https://img.shields.io/github/actions/workflow/status/Evil0ctal/Douyin_TikTok_Download_API/ci.yml?branch=main&style=flat-square&label=CI)](https://github.com/Evil0ctal/Douyin_TikTok_Download_API/actions/workflows/ci.yml)
[![CodeQL](https://img.shields.io/github/actions/workflow/status/Evil0ctal/Douyin_TikTok_Download_API/codeql.yml?branch=main&style=flat-square&label=CodeQL)](https://github.com/Evil0ctal/Douyin_TikTok_Download_API/actions/workflows/codeql.yml)
[![Last commit](https://img.shields.io/github/last-commit/Evil0ctal/Douyin_TikTok_Download_API?style=flat-square&label=last%20commit)](https://github.com/Evil0ctal/Douyin_TikTok_Download_API/commits/main)
<br>
[![Website](https://img.shields.io/badge/docs-douyin.wtf-2f6feb?style=flat-square&logo=readthedocs&logoColor=white)](https://douyin.wtf)
[![Live demo](https://img.shields.io/badge/demo-demo.douyin.wtf-22c55e?style=flat-square&logo=rocket&logoColor=white)](https://demo.douyin.wtf)
[![Python](https://img.shields.io/badge/python-3.12%2B-3776AB?style=flat-square&logo=python&logoColor=white)](./pyproject.toml)
[![MCP](https://img.shields.io/badge/MCP-ready-8A63D2?style=flat-square)](./documents/en/12-mcp.md)
[![Docker Pulls](https://img.shields.io/docker/pulls/evil0ctal/douyin_tiktok_download_api?style=flat-square&logo=docker&color=2496ed)](https://hub.docker.com/r/evil0ctal/douyin_tiktok_download_api)
[![Docker Image Size](https://img.shields.io/docker/image-size/evil0ctal/douyin_tiktok_download_api/latest?style=flat-square&logo=docker&color=2496ed)](https://hub.docker.com/r/evil0ctal/douyin_tiktok_download_api/tags)

</div>

## 💖 Sponsors

These sponsors paid to be here, and **Douyin_TikTok_Download_API** stays free and open because of it. To sponsor the project, see my [GitHub Sponsors page](https://github.com/sponsors/evil0ctal).

<div align="center">
    <a href="https://www.tikhub.io/?utm_source=douyin_tiktok_download_api&amp;utm_medium=referral&amp;utm_campaign=sponsor&amp;utm_content=readme_logo" target="_blank" rel="sponsored noopener">
        <img src="https://tikhub.io/logo.jpeg" width="100" alt="TikHub.io - Global Social Data & API Marketplace">
    </a>
    <h2>
        <a href="https://www.tikhub.io/?utm_source=douyin_tiktok_download_api&amp;utm_medium=referral&amp;utm_campaign=sponsor&amp;utm_content=readme_name" target="_blank" rel="sponsored noopener"><b>TikHub.io</b></a>
    </h2>
    <p>Your Ultimate Social Media Data &amp; API Marketplace</p>
    <p>
        Professional data solutions for Douyin, Xiaohongshu, TikTok, Instagram, YouTube,
        Twitter, and more.<br>
        Real-time Data | Flexible APIs | Seamless Integration | Competitive Pricing with Discounts
    </p>
    <p>
        Buy and sell custom APIs, services, and social media solutions on the<br>
        TikHub.io Marketplace, alongside developers, businesses and content creators.
    </p>
    <p><em>Trusted by leading global influencer marketing and social media intelligence platforms</em></p>
    <p>
        <a href="https://www.tikhub.io/?utm_source=douyin_tiktok_download_api&amp;utm_medium=referral&amp;utm_campaign=sponsor&amp;utm_content=readme_cta" target="_blank" rel="sponsored noopener"><b>→ Visit TikHub.io</b></a>
        &nbsp;·&nbsp;
        <a href="https://api.tikhub.io/?utm_source=douyin_tiktok_download_api&amp;utm_medium=referral&amp;utm_campaign=sponsor&amp;utm_content=readme_docs" target="_blank" rel="sponsored noopener">API docs</a>
    </p>
</div>

## 🧩 REER — a forum for reverse engineering

<div align="center">
    <a href="https://reer.dev" target="_blank" rel="noopener">
        <img src="./logo/reer.png" width="88" alt="REER">
    </a>
    <h3><a href="https://reer.dev" target="_blank" rel="noopener"><b>reer.dev</b></a></h3>
</div>

Somewhere to put what you work out. This project exists because people wrote down
how a signature was built; the forum is for the next round of that — signatures,
protocols, packers, anything taken apart.

Free, no advertising, and close to no rules beyond the obvious. Bilingual, English
and Chinese. Register and post; nothing is gated.

## 🎬 What it looks like

<div align="center">
    <img src="./screenshots/console-en.gif" width="900" alt="The DTK console: overview, identities, scheduler, playground, library, downloads, API docs and MCP"/>
</div>

One real call: paste a link, send it, get the normalised result back. The identity pool, the
scheduler and the API reference it passed through on the way are all in the same console.
The interface follows the browser's language, and both are written by hand rather than
machine-translated. [中文界面](./screenshots/console-zh.gif)

### Try it without installing anything

**<https://demo.douyin.wtf>** is a live instance, open to everyone. Sign in — the login page
fills the demo account in for you — and use the console: the playground, the scheduler,
the library, the API reference. The same account comes with an API key you can call the
scraping endpoints with, shown in plaintext on the API keys page.

It is read-only. Demo requests are not written to the request log or the archive, so the
database of a public instance cannot be filled by strangers, and switching demo mode off
ends every demo session and kills the key immediately.

**Rate limit: 30 requests per 10 seconds.** Go over it and you are cooled down for 10
seconds, during which every request is refused. It is a shared instance, and the identity
pool behind it is the ceiling for everybody using it at once.

What the demo is for is deciding whether to run your own. It is not a service to build
on — it can go down, be reset, or be switched off, and none of that will be announced.

## 🚀 v4 vs v5

v5 is a rewrite. It started from an empty branch and inherits no v4 code.

v4's real problem was never a shortage of features — it was that **the API would die
quietly and nobody would know**. A cookie expires, a signature algorithm changes, an
endpoint gets rate-limited, and you find out when someone files an issue. v5 puts
"you can see it" and "it heals itself" ahead of features.

| | v4 | v5 |
|---|---|---|
| Where identities come from | You copy cookies out of a browser into `config.yaml` | A headless browser mints guest identities, and the pool tops itself up when usable ones run low |
| How requests go out | Straight out, as they arrive | Health tiers, quantised LRU rotation, one in-flight lock per identity, a token bucket per (identity, endpoint), a circuit breaker per endpoint |
| When something breaks | You wait for a bug report | One structured record per request, live health for every identity and endpoint, visible in the console |
| Call style | Synchronous — send and wait | Asynchronous by default (`202` + `task_id`); add `?wait=` to go back to synchronous |
| What is kept | Nothing; parsed and discarded | PostgreSQL + Redis. Everything parsed is archived, so a post deleted upstream is still here |
| Access control | None; anyone can call it | API keys with scopes and roles, managed in the console |
| Interface | A single PyWebIO page | A React console: identity pool, scheduler, library, downloads, logs, diagnostics |
| Ways in | REST | REST, MCP and a CLI, all over the same service layer |
| Signing | X-Bogus, A_Bogus | a_bogus, X-Bogus, X-Gnarly, X-Dynosaur in pure Python, with a browser fallback |
| Deployment | `pip install -r requirements.txt` + `python start.py` | `docker compose up`, three images |
| Platforms | Douyin, TikTok, Bilibili | Douyin, TikTok |

Bilibili is the one thing that went backwards: v5 does not have it yet. It shares
neither the signing nor the identity machinery with Douyin and TikTok, so the rewrite
left it out for now.

### Still on v4?

v4's code stays on the [`v4` branch](https://github.com/Evil0ctal/Douyin_TikTok_Download_API/tree/v4),
the image is still published, and one command brings it up:

```bash
docker run -d --name dtk-v4 --restart unless-stopped \
  -p 8080:80 evil0ctal/douyin_tiktok_download_api:V4.1.2
```

Then open <http://localhost:8080>; the API reference is at `/docs`. Port 8080 is
deliberate — v5 binds 8000, so the two versions can run side by side on one machine.

**Replace the Douyin cookie before you use it.** v4 has no identity pool, and the cookie
baked into the image expired long ago, so Douyin endpoints answer `400` until you put
your own in:

```bash
docker cp dtk-v4:/app/crawlers/douyin/web/config.yaml ./douyin-web.yaml
# replace the Cookie line with one from your browser, then save
docker rm -f dtk-v4
docker run -d --name dtk-v4 --restart unless-stopped -p 8080:80 \
  -v "$PWD/douyin-web.yaml:/app/crawlers/douyin/web/config.yaml" \
  evil0ctal/douyin_tiktok_download_api:V4.1.2
```

TikTok's two config files are at `/app/crawlers/tiktok/web/config.yaml` and
`/app/crawlers/tiktok/app/config.yaml`, and are mounted the same way.

To keep it under Compose instead, one file is enough — with `douyin-web.yaml` already
copied out next to it, or Docker will create a *directory* under that name and the app
will fail to read its config:

```yaml
# compose.yml
services:
  app:
    image: evil0ctal/douyin_tiktok_download_api:V4.1.2
    container_name: dtk-v4
    restart: unless-stopped
    ports:
      - "8080:80"
    environment:
      TZ: Asia/Shanghai
    volumes:
      - ./douyin-web.yaml:/app/crawlers/douyin/web/config.yaml
```

```bash
docker rm -f dtk-v4   # the container from the run above holds the name
docker compose -p dtk-v4 up -d
```

`main` is v5 now and `latest` follows `main`, so **pin the tag to stay on v4**. `V4.1.2`
is the last v4 release; the branch merged a few PRs after it (Bilibili downloads, cookie
hot-reload), and that code is published under the commit tag `5be4838`.

There is no guided installer for v4 — the script in Quick start below installs v5. What
is above is all v4 gets: the branch still takes PRs, but nothing new is built on it, and
a fresh install should start on v5.

### Building this together

There are a few group chats around my open-source projects. If you want to work
on this one, or just talk shop, add me on WeChat at **`Evil0ctal`** with the note
**github 交流** and I will add you.

The groups are for learning from each other. **No advertising and nothing
illegal** — they are for making friends and talking about the work.


## 📦 What it can fetch from Douyin and TikTok

| Capability | Douyin | TikTok |
|---|:---:|:---:|
| One post (video or image album) | ✅ | ✅ |
| Author profile | ✅ | ✅ |
| An author's posts | ✅ | ✅ |
| An author's liked posts | ✅ | ✅ |
| Mixes / playlists | ✅ | ✅ |
| Comments | ✅ | ✅ |
| Comment replies | ✅ | ✅ |
| Followers | ❌ | ✅ |
| Following | ❌ | ✅ |

Douyin serves its follower and following lists only to a signed-in session, so those
two endpoints are not registered at all: an endpoint that always returns an empty page
is worth nothing. Importing your own logged-in cookies widens what the rest can see, too.

Media downloads, the content archive, counter snapshots, collections and a watchlist
are built in; none of them needs another service.

## 🔗 Which Douyin and TikTok links it accepts

Paste whatever you have — a short link, a post URL, or the whole caption a platform app
puts on your clipboard:

```
https://v.douyin.com/L4NpDJ6/
https://www.douyin.com/video/7126745726494821640
https://www.douyin.com/jingxuan?modal_id=7660875690212492466
https://www.tiktok.com/@evil0ctal/video/7156033831819037994
https://www.tiktok.com/t/ZTR9nkkmL/
2.84 nqe:/ <caption> https://v.douyin.com/L4FJNR3/ <sentence telling you to open the app>
```

Short links are followed and a link buried in a caption is extracted. A post id is also
checked against the platform's own encoding first, so an id that cannot exist is refused
here rather than costing an upstream request.

## ⚗️ Built with

| | |
|---|---|
| Service | Python 3.12 · FastAPI · SQLAlchemy 2.0 (async) · Alembic · Typer · structlog |
| Transport | wreq (browser TLS fingerprint emulation) · httpx |
| Data | PostgreSQL + TimescaleDB · Redis |
| Console | React 19 · TypeScript · Vite · TanStack Query · wouter · i18next |
| Signing | a_bogus, X-Bogus, X-Gnarly and X-Dynosaur in pure Python |
| Identity minting | CloakBrowser, headless, in a container of its own, called over HTTP |
| Downloader | Go 1.23, standard library only, statically linked into a scratch image |
| Auth | argon2id password hashing · API keys with scopes |
| Protocols | REST (OpenAPI) · MCP (streamable-http) · CLI |
| Tooling | uv · ruff · mypy · pytest · Docker Compose |

Nothing beyond Postgres and Redis is required. No Kafka, no Elasticsearch, no object
store, no Kubernetes.

CloakBrowser is pinned to a specific commit. That pin is a security control — see
[docker/Dockerfile.browser](./docker/Dockerfile.browser).

## 🗂 Project layout

**First, what `dtk` is.** `Douyin_TikTok_Download_API` is a mouthful, so the code
says **DTK** instead: **D**ouyin + **T**i**K**Tok. The two platforms, and not the
download or API halves of the name.

It is the Python package (`src/dtk/`), the command (`dtk --help`), the prefix on
every environment variable (`DTK_SECRET_KEY` and friends), the Compose project
name (`-p dtk`), and the three letters in the console's title bar. Where you see
`dtk`, it means `Douyin_TikTok_Download_API`.

```
Douyin_TikTok_Download_API/
├── src/dtk/                the service; all of it lives here
│   ├── api/                FastAPI routes, auth, OpenAPI localisation
│   ├── platforms/          Douyin and TikTok adapters: endpoints, params, parsers
│   ├── signing/            a_bogus / X-Bogus / X-Gnarly / X-Dynosaur
│   ├── transport/          outbound requests, response classification
│   ├── identity/           identity minting and health
│   ├── scheduler/          identity selection, token buckets, circuit breakers
│   ├── services/           the business layer, shared by REST, MCP and the CLI
│   ├── worker/             async tasks, callbacks, scheduled collection
│   ├── db/                 SQLAlchemy models and Alembic migrations
│   ├── ops/                diagnostics, backups, health checks, alerting
│   ├── media/              downloader client
│   ├── models/             one content model across both platforms
│   ├── urls/               link recognition, short-link expansion, id validation
│   ├── mcp/                MCP server
│   ├── cli/                the dtk command line
│   ├── i18n/               server-side English and Chinese strings
│   └── core/               settings, logging, error types
├── web/                    the React console, built into the app image
│   └── src/
│       ├── pages/          one file per console page
│       ├── components/     design system and shared components
│       └── locales/        console English and Chinese strings
├── docker/                 three Dockerfiles, compose, and two sidecars
│   ├── browser_rpc/        Python, wrapping CloakBrowser
│   ├── downloader/         Go, the media download sidecar
│   └── compose.yml
├── documents/              user documentation, 17 pages in each language
├── tests/                  unit / integration / contract / replay
├── scripts/                smoke.sh
├── .github/workflows/      CI and Docker image publishing
├── alembic.ini
├── pyproject.toml
└── Makefile
```

## ⚡️ Quick start: self-host it with Docker

If you would rather not think about it, the guided script asks a few questions and
brings the stack up — it works out your distribution, checks for Docker, and
scales the resource limits to the machine:

```bash
curl -fsSL https://raw.githubusercontent.com/Evil0ctal/Douyin_TikTok_Download_API/main/install/install.sh -o install.sh
less install.sh    # reading it first is a good habit
bash install.sh
```

**Afterwards the same script is the operations tool.** Run it again and it finds the install and opens a menu: status, upgrade (compared against the latest GitHub release), passwords, an extra administrator, backup and restore, runtime settings, disk cleanup, stop or uninstall. `--manage` goes straight there.

Details in [install/README.md](./install/README.md). The manual route follows.

There are two ways to install this; below is the recommended one. For the by-hand route, see
[Without Docker](#without-docker).

| How | Who for | Full steps |
|---|---|---|
| **Docker Compose** (recommended) | Almost everyone, production included | [Installation · First install](./documents/en/02-installation.md#first-install) |
| By hand | Docker is not an option, or you are changing the code | [For development](./documents/en/02-installation.md#running-without-docker) · [On bare metal](./documents/en/02-installation.md#a-production-install-without-docker) |

> **Installing from mainland China?** Switch your mirrors before you start, or the pull will
> most likely time out:
> [Network preparation in mainland China](./documents/en/02-installation.md#network-preparation-in-mainland-china).

You need Docker and Docker Compose. Start by cloning the repository — the compose file,
the Dockerfiles and the migrations all live in it, and the default branch is v5:

```bash
git clone https://github.com/Evil0ctal/Douyin_TikTok_Download_API.git
cd Douyin_TikTok_Download_API
```

Nothing in the repository ships a default password or key, so write `.env` next:

```bash
POSTGRES_PASSWORD=$(openssl rand -hex 24)
REDIS_PASSWORD=$(openssl rand -hex 24)
cat > .env <<EOF
DTK_SECRET_KEY=$(openssl rand -base64 48)
POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
REDIS_PASSWORD=${REDIS_PASSWORD}
DTK_DATABASE_URL=postgresql+asyncpg://dtk:${POSTGRES_PASSWORD}@postgres:5432/dtk
DTK_REDIS_URL=redis://:${REDIS_PASSWORD}@redis:6379/0
EOF
```

```bash
docker compose -p dtk -f docker/compose.yml up -d
docker compose -p dtk -f docker/compose.yml logs api   # prints the setup token
```

Open <http://127.0.0.1:8000> and use the token from the log to create the first
administrator.

### Where the image comes from

By default it is built locally: the first `up` compiles the application image from the
Dockerfile in this repository, which takes a few minutes. To skip that, point compose at
the published image instead:

```bash
export DTK_IMAGE=evil0ctal/douyin_tiktok_download_api
export DTK_IMAGE_TAG=latest
docker compose -p dtk -f docker/compose.yml pull
docker compose -p dtk -f docker/compose.yml up -d
```

The `pull` is not optional: these services declare both `image` and `build`, so compose
builds from the local Dockerfile whenever the image is not already on the machine rather
than reaching for a registry.

Images are published for `linux/amd64` and `linux/arm64`, so Apple Silicon and a
Raspberry Pi both run natively. The browser container is not published: it installs
CloakBrowser from a pinned commit, and that pin is a security control that should be
yours to choose, so it stays a local build.

### Without Docker

Supported, and it is how the project itself is developed. You provide PostgreSQL 17 (**with the
TimescaleDB extension** — a plain `postgres:17` will not do), Redis 8, Python 3.12 and uv, plus
Node 22 if you build the console. Two sets of steps:

- [Running without Docker](./documents/en/02-installation.md#running-without-docker) — for
  development; Postgres and Redis still come from containers
- [A production install without Docker](./documents/en/02-installation.md#a-production-install-without-docker)
  — all of it by hand, systemd units included, verified on a clean Ubuntu 24.04

What the containers were doing for you — a non-root user, memory and CPU ceilings, a read-only root
filesystem, process supervision — you put back yourself. That section lists them one by one.

### Where to look next

| What you want to do | Where |
|---|---|
| Size a machine, change the container limits | [Three sizes](./documents/en/02-installation.md#three-sizes) · [Changing the limits](./documents/en/02-installation.md#changing-the-limits) |
| Turn on the browser container or the downloader sidecar | [The two optional profiles](./documents/en/02-installation.md#the-two-optional-profiles) |
| Put TLS and a reverse proxy in front | [Behind a reverse proxy](./documents/en/02-installation.md#behind-a-reverse-proxy) |
| Understand how the environment is actually read | [Environment variables](./documents/en/02-installation.md#environment-variables) |
| Confirm an install is genuinely healthy | [Verifying an install](./documents/en/02-installation.md#verifying-an-install) |
| Read the compose file line by line | [docker/README.md](./docker/README.md) |

## 🖥 What you get: console, REST API, MCP and CLI

| Entry point | Where | What it is |
|---|---|---|
| Web console | `/` | Identity pool, scheduler, library, downloads, logs, diagnostics |
| API reference | `/docs` | Swagger UI inside the console, English and Chinese |
| Bare reference | `/swagger`, `/redoc` | No login required |
| REST API | `/api/v1/...` | 93 operations |
| MCP | `/mcp` | Shares the service layer with REST; client setup at `/mcp-guide` in the console |
| CLI | `dtk --help` | Same |

The main capabilities:

- **Parse** a link, share text, short link, or a bare post id
- **Archive** everything parsed, so a post deleted upstream is still here
- **Download** media to your own disk, in bulk by author, skipping what you have,
  with duplicate cleanup
- **Watch** an author or a post and re-collect it on a timer
- **iOS Shortcut** support at `/api/v1/ios/shortcut`

## 🔄 Updating to a new release

The console keeps an eye out for you: `system.check_updates` is on by default,
and if a newer release exists you get one notice after signing in, at most once
a day. That request goes from **your browser** to GitHub — the server never
sends anything outward, so it does not tell anyone this instance exists. Turn it
off in Settings if you would rather it did not.

Updating is a pull and a restart. If you installed with the script, run it
again and pick Upgrade:

```bash
bash install.sh --manage    # pick 2
```

By hand it is:

```bash
cd /opt/dtk && git pull

# Running the published images (recommended): point DTK_IMAGE_TAG at the new one
docker compose -p dtk -f docker/compose.yml pull api worker downloader
docker compose -p dtk -f docker/compose.yml run --rm migrate
docker compose -p dtk -f docker/compose.yml up -d
```

Building locally instead? Swap `pull` for `build`. `migrate` runs on every start
and Alembic is idempotent, so running it separately is only about getting the
schema up before the containers switch over.

**Your data stays put.** The named volumes (`postgres-data`, `redis-data`,
`media-data`) survive a rebuild, so the identity pool, the archive, the settings
and the API keys are all where you left them.

The browser image only needs rebuilding when `docker/Dockerfile.browser` or the
CloakBrowser pin changes, which a normal version bump does not touch.

To go back, set `DTK_IMAGE_TAG` to the previous `sha-` or version and `up -d`
again. Migrations have no automatic downgrade — back the database up before
upgrading, which is the only rollback that always works.


## 📖 Documentation

**Read it online at [douyin.wtf](https://douyin.wtf)** — the same 17 pages, rendered,
searchable and in both languages. The markdown source is in
[`documents/`](./documents/README.md) and is what the site is built from, so the two
never disagree.

**New here:**
[Quick start](./documents/en/01-quickstart.md) ·
[Concepts](./documents/en/04-concepts.md) ·
[Console overview](./documents/en/05-console-overview.md)

**Running it:**
[Installation and deployment](./documents/en/02-installation.md) ·
[Configuration reference](./documents/en/03-configuration.md) ·
[Operations](./documents/en/10-operations.md) ·
[Troubleshooting](./documents/en/14-troubleshooting.md) ·
[Security](./documents/en/15-security.md)

**Building against it:**
[REST API guide](./documents/en/11-api.md) ·
[MCP and AI agents](./documents/en/12-mcp.md) ·
[CLI reference](./documents/en/13-cli.md) ·
[Contributing](./documents/en/16-contributing.md)

The endpoint reference is not in there: it is generated from the code that serves the
requests, so your own instance is the copy that is never out of date. Find it at `/docs`
inside the console, or at `/swagger`, `/redoc` and `/openapi.json` without a login. Both
languages.

中文文档：[`documents/README.zh-CN.md`](./documents/README.zh-CN.md)

**Reading this with an LLM?** [`llms.txt`](./llms.txt) is the whole documentation set
as one annotated index, in the [llmstxt.org](https://llmstxt.org) format.

## 📮 Contact

| | |
|---|---|
| Issues | [GitHub Issues](https://github.com/Evil0ctal/Douyin_TikTok_Download_API/issues) — public, keeps its history, and anyone who has hit the same thing can answer |
| Email | `Evil0ctal1985@gmail.com` — reaches one person; best for anything that does not belong in public |
| Author | [@Evil0ctal](https://github.com/Evil0ctal) |

Before asking, read [Troubleshooting](./documents/en/14-troubleshooting.md) and include
the output of the Diagnose page or `dtk diagnose`. It answers most of what a maintainer
would otherwise have to ask you.

## ⭐️ Star history

[![Star History Chart](https://api.star-history.com/svg?repos=Evil0ctal/Douyin_TikTok_Download_API&type=Timeline)](https://star-history.com/#Evil0ctal/Douyin_TikTok_Download_API&Timeline)

> Started 2021/11/06 · GitHub [@Evil0ctal](https://github.com/Evil0ctal)

## 📄 Licence

[Apache License 2.0](./LICENSE).

You may use, modify and distribute this project, **including commercially and inside
closed-source products**. The grant is irrevocable. In return the licence asks you to:

- Keep the copyright notice and the licence text with any copy you distribute
- State what you changed, in files you modified
- Accept that it comes with no warranty

### A request from the author

This project is given away, and it stays free because sponsors pay for it rather than
users. **If you are making money from it, please consider sponsoring instead of only
taking.**

This is a request, not a licence condition — Apache 2.0 permits commercial use, and
nothing above takes that back.

## ☕️ Support the author

The sponsors above pay for the **project**. This section is for the **person who
maintains it**, and is entirely optional.

| Network | Address |
|---|---|
| Solana | `HvtkxmDERbNXfCoojpdFAYN5mSWowjpXgedsG9eF7y9z` |
| Tron (TRC20) | `TQwSM2vjcnrdRU7gY7KNp2tCgMnK33azkT` |
| Ethereum (ERC20) | `0x2f210FdfD981B59eC130370E5b1Aa8A6a06fb5Ad` |
| BNB Smart Chain (BEP20) | `0x2f210FdfD981B59eC130370E5b1Aa8A6a06fb5Ad` |
| Bitcoin | `bc1q785j55cxlnjqe8lkwy8cq57t8t9vn3ak9tlsfy` |

These networks carry the usual major tokens. **USDT on Tron (TRC20) or Solana** is the
easiest to receive, and the cheapest to send.

> **Send only on the network an address is listed under.** A transfer on the wrong chain
> cannot be recovered by anybody.
> Ethereum and BNB Smart Chain share one address on purpose: both are EVM chains, and
> the same key controls it.

[GitHub Sponsors](https://github.com/sponsors/evil0ctal) works too.

### What you are responsible for

This fetches data from platforms that have their own terms, and it runs on your machine
under your control. Respect those terms and applicable law, respect the people whose
content you collect, do not use it to harass anyone, and do not redistribute work that
is not yours. Nobody else can enforce any of that for you.
